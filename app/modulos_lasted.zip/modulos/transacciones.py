from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from .. import models

router = APIRouter(prefix="/transacciones", tags=["Transacciones"])

@router.post("/operacion")
def realizar_transaccion(cuenta_id: int, tipo: str, monto: float, db: Session = Depends(get_db)):
    cuenta = db.query(models.Cuenta).filter(models.Cuenta.id == cuenta_id).first()
    if not cuenta:
        raise HTTPException(status_code=404, detail="Cuenta no encontrada")
    
    if tipo.upper() == "RETIRO":
        if cuenta.saldo < monto:
            raise HTTPException(status_code=400, detail="Saldo insuficiente")
        cuenta.saldo -= monto
    elif tipo.upper() == "DEPOSITO":
        cuenta.saldo += monto
    else:
        raise HTTPException(status_code=400, detail="Tipo de operación inválida")
    
    nueva_transaccion = models.Transaccion(tipo=tipo.upper(), monto=monto, cuenta_id=cuenta_id)
    db.add(nueva_transaccion)
    db.commit()
    return {"mensaje": "Transacción exitosa", "nuevo_saldo": cuenta.saldo}