from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.sql import func
from .database import Base

class Socio(Base):
    __tablename__ = "socios"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100))
    cedula = Column(String(10), unique=True)

class Cuenta(Base):
    __tablename__ = "cuentas"
    id = Column(Integer, primary_key=True, index=True)
    numero_cuenta = Column(String(20), unique=True)
    saldo = Column(Float, default=0.0)
    socio_id = Column(Integer, ForeignKey("socios.id"))

class Transaccion(Base):
    __tablename__ = "transacciones"
    id = Column(Integer, primary_key=True, index=True)
    tipo = Column(String(20)) # DEPOSITO o RETIRO
    monto = Column(Float)
    fecha = Column(DateTime(timezone=True), server_default=func.now())
    cuenta_id = Column(Integer, ForeignKey("cuentas.id"))

class Prestamo(Base):
    __tablename__ = "prestamos"
    id = Column(Integer, primary_key=True, index=True)
    monto_aprobado = Column(Float)
    cuotas = Column(Integer)
    socio_id = Column(Integer, ForeignKey("socios.id"))