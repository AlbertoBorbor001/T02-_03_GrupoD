from fastapi import FastAPI
from .database import engine
from . import models
from .modulos import socios, transacciones, prestamos

app = FastAPI(title="Sistema Caja de Ahorros - Grupo D")

# Crea las tablas automáticamente en Aiven
models.Base.metadata.create_all(bind=engine)

app.include_router(socios.router)
app.include_router(transacciones.router)
app.include_router(prestamos.router)

@app.get("/")
def inicio():
    return {"mensaje": "API Grupo D Online"}